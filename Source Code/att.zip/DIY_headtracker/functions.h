
#ifndef functions_h
#define functions_h


void init_timer_interrupt();
void get_data();
void set_pwm();
void test_output();
void init_pwm_interrupt();
void detect_PPM();
void printPPM();

#endif
