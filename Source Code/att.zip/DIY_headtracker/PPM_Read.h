

void detectPPM();
void pinChangeInterrupt();
